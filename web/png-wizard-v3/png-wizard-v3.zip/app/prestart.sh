#!/bin/sh
service cron start